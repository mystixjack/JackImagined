# Jack Imagined — website

Static, mobile-responsive site: `index.html`, `shop.html`, `portfolio.html`, `book.html`, `checkout.html`, styled by `css/style.css`, powered by `js/main.js`.

Open `index.html` in a browser to preview. To go live, upload the whole folder to any static host (Netlify, Vercel, GitHub Pages, or your own hosting) — no build step required.

## Why some things are "demo mode"

A pure HTML/CSS/JS site runs entirely in the visitor's browser, so it **can't safely hold secret API keys** (Printify's API token, Stripe's secret key). Anything secret needs a small server in between. Below is exactly what to connect and where.

## Connecting Printify

Printify's API requires a private token that must stay server-side. Two paths:

1. **Simplest — no code:** Connect Printify's built-in **Shopify, Etsy, or WooCommerce** sales channel instead of custom code. Printify natively syncs products, inventory, and order fulfillment to any of those platforms. You'd rebuild this site's look inside that platform's theme editor using this CSS as your style guide.
2. **Keep this custom site:** Write a small serverless function (Netlify/Vercel Functions or a tiny Node server) that:
   - Holds your Printify API token as an environment variable
   - Calls `GET https://api.printify.com/v1/shops/{shop_id}/products.json`
   - Returns the product list as JSON to your site
   
   Then replace the `PRODUCTS` array at the top of `js/main.js` with a `fetch('/api/products')` call to that endpoint. The rest of the cart/shop code already expects that same shape (`id`, `name`, `price`, `category`).

## Connecting Stripe

No backend needed for single-item purchases:

1. In the Stripe Dashboard, create a Product + Price for each item, then create a **Payment Link** for it.
2. Paste each link into the matching product's `stripeLink` field in `js/main.js`.
3. "Buy now" and single-item checkout will redirect straight to Stripe's hosted, PCI-compliant checkout — your site never touches card data.

For a real multi-item cart charged in one transaction, add a small serverless function that calls `stripe.checkout.sessions.create()` with your cart's line items and your **secret key** (server-side only), then redirect the browser to the returned session URL. Swap the `alert()` inside `goToStripeCheckout()` in `js/main.js` for that redirect.

## Connecting PayPal

1. Get a **Client ID** from the [PayPal Developer Dashboard](https://developer.paypal.com/) (this one is safe to expose in front-end code — it's not a secret).
2. In `checkout.html`, replace `REPLACE_WITH_YOUR_PAYPAL_CLIENT_ID` in the `<script src="https://www.paypal.com/sdk/js?...">` tag.
3. The Smart Buttons in `js/main.js` (`initPayPalButton`) will render and process real payments once the client ID is live.
4. For production, verify the completed order server-side using PayPal's Orders API before marking anything as fulfilled — client-side capture alone can be replayed or interrupted.

## Connecting Interac e-Transfer

Interac e-Transfer has no public checkout API for small merchants — it's handled manually, which is normal for independent Canadian shops:

1. Set up **Autodeposit** on a business bank account so incoming e-Transfers land automatically without a security answer (recommended), or set a fixed security answer as shown on the checkout page.
2. Replace `payments@jackimagined.com` in `checkout.html` with your real e-Transfer email.
3. The confirmation form on the checkout page is a working demo that shows a success message. Connect its `action` to [Formspree](https://formspree.io) (free tier available), a Google Sheet via Apps Script, or your own backend so submissions reach your inbox — see the matching note next to the Commission form in `portfolio.html` for the same pattern.
4. Manually confirm and mark the order paid once the e-Transfer arrives.

## Making the cart persistent

The cart currently lives in memory (a JS array in `js/main.js`) and clears on page reload — this keeps the demo simple and avoids browser storage quirks in preview tools. For a live site, swap the `cart` array for `sessionStorage`/`localStorage` reads and writes (a few lines in `addToCart`, `removeFromCart`, and on page load), or move cart state to your backend if you add user accounts.

## Fonts & assets

Typefaces load from Google Fonts (Anton, Work Sans, JetBrains Mono) via the `<link>` tags in each page's `<head>`. All product photos, portfolio pieces, and the book cover are placeholder gradient blocks (`.card-media`, `.masonry-item`, `.book-cover`) — replace them with your own `<img>` tags using real photography.
